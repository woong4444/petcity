CREATE TABLE MAIN_BANNER (
                             BANNER_ID NUMBER PRIMARY KEY,

                             TITLE VARCHAR2(200 CHAR),
                             SUB_TITLE VARCHAR2(500 CHAR),

                             IMAGE_URL VARCHAR2(1000 CHAR) NOT NULL,
                             LINK_URL VARCHAR2(1000 CHAR),

                             DISPLAY_ORDER NUMBER DEFAULT 0 NOT NULL,

                             ACTIVE_YN CHAR(1) DEFAULT 'Y' NOT NULL
                                 CHECK (ACTIVE_YN IN ('Y', 'N')),

                             START_AT TIMESTAMP,
                             END_AT TIMESTAMP,

                             CREATED_AT TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL,
                             UPDATED_AT TIMESTAMP
);
--추가사항
ALTER TABLE MAIN_BANNER
    MODIFY (
    TITLE NOT NULL,
    DISPLAY_ORDER DEFAULT 1,
    UPDATED_AT DEFAULT SYSTIMESTAMP
    );

ALTER TABLE MAIN_BANNER
    ADD CONSTRAINT CK_MAIN_BANNER_ACTIVE_YN
        CHECK (ACTIVE_YN IN ('Y', 'N'));

ALTER TABLE MAIN_BANNER
    ADD CONSTRAINT CK_MAIN_BANNER_DISPLAY_ORDER
        CHECK (DISPLAY_ORDER >= 1);

ALTER TABLE MAIN_BANNER
    ADD CONSTRAINT CK_MAIN_BANNER_PERIOD
        CHECK (
            START_AT IS NULL
                OR END_AT IS NULL
                OR START_AT <= END_AT
            );

CREATE SEQUENCE MAIN_BANNER_SEQ
    START WITH 1
    INCREMENT BY 1
    NOCACHE;

CREATE INDEX IDX_MAIN_BANNER_ACTIVE_ORDER
    ON MAIN_BANNER (ACTIVE_YN, DISPLAY_ORDER);